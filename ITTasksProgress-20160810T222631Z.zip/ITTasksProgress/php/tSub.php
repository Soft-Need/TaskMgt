
<?php
//Get connection
require('data.php');

 $sql1 = "SELECT sub.Progress as 'مستوى التقدم', sub.Incharge as 'الموظف المكلف',sub.stask_des as 'وصف المهمة', sub.STname as 'المهمة', main.Tname as 'المشروع' FROM main INNER JOIN sub ON main.ID = sub.ID where main.id = ";
 $sql2 = $_GET['id'];
 $sql3 = $sql1 . $sql2;
$result = mysqli_query($connection, $sql3);

$all_property = array();  //declare an array for saving property

while ($property = mysqli_fetch_field($result)) {

  //get field name for header
    array_push($all_property, $property->name);  //save those to array
}

//showing all data
while ($row = mysqli_fetch_array($result)) {
 
 $_POST['title'] = $row[4];

}

echo '<h1 id="Headertxt" ><center>'.$_POST['title'].'</center></h1>'
?>

<?php
//Get connection
require('data.php');

 $sql1 = "SELECT sub.Progress as 'مستوى التقدم', sub.Incharge as 'الموظف المكلف',sub.stask_des as 'وصف المهمة', sub.STname as 'المهمة', main.Tname as 'المشروع' FROM main INNER JOIN sub ON main.ID = sub.ID where main.id = ";
 $sql2 = $_GET['id'];
 $sql3 = $sql1 . $sql2 .' limit 5 offset ' . pageno() ;
$result = mysqli_query($connection, $sql3);

$all_property = array();  //declare an array for saving property
 //searchbox



// echo'<div class="col-sm-2 pull-right"><form role="search"style="width: 100%; margin-left: 13px; margin-bottom: 10px ">
    // <div class="input-group">
        // <input name = "searchbox" type="text" class="form-control" placeholder="Search" value='.$_Get['searchvalue'].'>
        // <div class="input-group-btn">
            // <a type= "submit" class="btn btn-success" href="sub.php?id='.$_GET['id'].'&Page='.$_GET['Page'].'value='.checkvalue($_post[(searchbox)]).'">
                // <span class="fa fa-search aria-hidden="true""></span>
            // </a>
        // </div>
    // </div>
// </form></div>';



//Get Table
//showing property
echo '<table class="table">
        <tr class="data-heading success">';  //initialize table tag
while ($property = mysqli_fetch_field($result)) {
    echo '<td><center>' . $property->name . '</center></td>';
  //get field name for header
    array_push($all_property, $property->name);  //save those to array
}
echo '</tr>' ; //end tr tag


//showing all data
while ($row = mysqli_fetch_array($result)) {
 
 


    echo "<tr>";
    foreach ($all_property as $item) {
        //bars
		if(is_numeric($row[$item])){
			
			echo '<td><progress style= "margin-bottom:0px; vertical-align:top; width: 100%" class= "progress progress-succes" value="'. $row[$item] .'" max="100" data-toggle="tooltip" data-placement="top" title="'. $row[$item] .'%"></progress></td>'; //get items using property value
			
		}else{
			
			
			echo '<td ><center>' . $row[$item] . '</center></td>'; //get items using property value
		};
    }
	
	
    echo '</tr>';
	
}




echo "</table>";




//Get pagenation

 echo "<nav aria-label=''>
   <ul class='pagination' style='margin-top: 5px'>
     <li class='page-item'>
	 <a tabindex='-1'aria-label='Previous' class='page-link' value='1' href='sub.php?id=".$_GET['id']."&Page=1'>
         <span aria-hidden='true'>&laquo;</span>
         <span class='sr-only'>Previous</span>
      </a>
     </li>";
   
   	$_GET['$rcount'] =  mysqli_num_rows($result);
	$pagesnum =  ceil($_GET['$rcount']/2);

	echo '<li class="page-item">
     </li>';
	for($x=1;$x<=$pagesnum;$x++){
		
		$_GET['Page']= $x;
		
		echo "<li class='page-item'><a method='Get' class='page-link active' value=".$x." href='sub.php?id=".$_GET['id']."&Page=".$_GET['Page']."'>".$_GET['Page']."</a></li>";

	};

	
	echo "<li class='page-item'>
	<a aria-label='Next' class='page-link' value=".$x." href='sub.php?id=".$_GET['id']."&Page=".$_GET['Page']."'>
        <span aria-hidden='true'>&raquo;</span>
        <span class='sr-only'>Next</span>
      </a>
    </li>
  </ul>
</nav>";




   function pageno(){

for($x=0;$x<$_GET['Page'];$x++){
	
	$offset = 5 * $x ;

};

	return $offset;	
 };
                        


  
?>