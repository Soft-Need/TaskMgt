
<?php

$host    = "localhost";
$user    = "a.tayeb";
$pass    = "abam6644";
$db_name = "ITTasksProgress";

//create connection
/*  @mysqli_set_charset('utf8', $connection);
 @mysqli_query("SET NAMES 'utf8'"); 
@mysqli_query('SET CHARACTER SET utf8');
@mysqli_query ("set character_set_results='utf8'"); 
 @mysqli_query ("set character_set_client='utf8'"); 
 @mysqli_query ("set character_set_results='utf8'"); 
 @mysqli_query ("set collation_connection='utf8_general_ci'"); */

$connection = @mysqli_connect($host, $user, $pass, $db_name);
@mysqli_query("Set NAMES 'utf8';");
@mysqli_query("Set CHARACTER SET 'utf8';");


//test if connection occured
if(mysqli_connect_errno()){
    die("connection failed: "
        . mysqli_connect_error()
        . " (" . mysqli_connect_errno()
        . ")");
}

/* SELECT progress as 'مستوى التقدم', Tname as 'اسم المشروع', id as 'رقم المشروع'  from main */
$result = mysqli_query($connection,"SELECT progress as 'مستوى التقدم',ben_dept as 'الجهة المستفيده',Task_des as 'وصف المشروع', Tname as 'اسم المشروع', id as 'رقم المشروع'  from main limit 10");

$all_property = array();  //declare an array for saving property

//showing property
echo '<table class="table">
        <tr class="data-heading success"> <td><center>تفاصيل المشروع</center></td>';  //initialize table tag
while ($property = mysqli_fetch_field($result)) {
    echo '<td><center>' . $property->name . '</center></td>';
  //get field name for header
    array_push($all_property, $property->name);  //save those to array
}
echo '</tr>' ; //end tr tag



//showing all data
while ($row = mysqli_fetch_array($result)) {
	

    echo "<tr><td><center><a class='btn btn-success btn-sm' type='button' href ='sub.php?id=".$row[4]."&Page=1'>تفاصيل</a></center></td>";
  
 

	
	
	foreach ($all_property as $item) {
		
        echo '<td><center>' . $row[$item] . '</center></td>'; //get items using property value

    }
				
		
    echo '</tr>';
}
echo "</table>";




  
?>

