<?php
$host    = "localhost";
$user    = "a.tayeb";
$pass    = "abam6644";
$db_name = "ITTasksProgress";


$connection = @mysqli_connect($host, $user, $pass, $db_name);
@mysqli_query("Set NAMES 'utf8';");
@mysqli_query("Set CHARACTER SET 'utf8';");


//test if connection occured
if(mysqli_connect_errno()){
    die("connection failed: "
        . mysqli_connect_error()
        . " (" . mysqli_connect_errno()
        . ")");
}
?>